<?php
include 'header.php';
 ?>

   <!-- MAIN CONTENT AREA STARTS -->

   <div class="timetable-container">
       <div class="timetable-list table-container" id="Table">
         <table>

           <thead>
             <tr class="text-center">
               <th>
                 <a> Classes </a>
               </th>
               <th>
                 <a> Time </a>
               </th>
               <th>
                 <a> Details </a>
               </th>
               <th>

               </th>
             </tr>
           </thead>

           <tbody class="table-bordered" id="TableBody">

             <tr>
               <td class="timetable-heading">Yoga <br><span> Main Studio with Louisa Parker</span> </td>
               <td class="text-center">06:45</td>
               <td class="text-center">
                  30 min
               </td>
               <td class="text-center">

                     <a data-open"loginModal" class="button about-button">Please Login</a>
               </td>
             </tr>

             <tr>
               <td class="timetable-heading">BodyTone<br><span>Main Studio with Joe Cooper</span></td>
               <td class="text-center">07:00</td>
               <td class="text-center">
                  60 min
               </td>
               <td class="text-center">
                     <a href="memberships.php" class="button about-button">Please Login</a>
               </td>
             </tr>

             <tr>
               <td class="timetable-heading">Boxersize<br><span>Main Studio with David Clayton</span></td>
               <td class="text-center">09:30</td>
               <td class="text-center">
                  60 min
               </td>
               <td class="text-center">
                     <a href="memberships.php" class="button about-button">Please Login</a>
               </td>
             </tr>

             <tr>
               <td class="timetable-heading" >GloboGym Cycle<br> <span>Main Studio with Vicky Walker</span></td>
               <td class="text-center">10:00</td>
               <td class="text-center">
                  60 min
               </td>
               <td class="text-center">
                     <a href="memberships.php" class="button about-button">Please Login</a>
               </td>
             </tr>

             <tr>
               <td class="timetable-heading">Boxersize<br> <span>Main Studio with David Clayton</span></td>
               <td class="text-center">12:15</td>
               <td class="text-center">
                  60 min
               </td>
               <td class="text-center">
                     <a href="memberships.php" class="button about-button">Please Login</a>
               </td>
             </tr>

             <tr>
               <td class="timetable-heading">Yoga<br> <span>Main Studio with Louisa Parker</span></td>
               <td class="text-center">15:45</td>
               <td class="text-center">
                  30 min
               </td>
               <td class="text-center">
                     <a href="memberships.php" class="button about-button">Please Login</a>
               </td>
             </tr>

             <tr>
               <td class="timetable-heading">BodyTone<br> <span>Main Studio with Joe Cooper</span></td>
               <td class="text-center">16:15</td>
               <td class="text-center">
                  60 min
               </td>
               <td class="text-center">
                     <a href="memberships.php" class="button about-button">Please Login</a>
               </td>
             </tr>
           </tbody>
         </table>

       </div>
     </div>


   <!-- MAIN CONTENT AREA ENDS -->

 <?php
 include 'footer.php';
 ?>
