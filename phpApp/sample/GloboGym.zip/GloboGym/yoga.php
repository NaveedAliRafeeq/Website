<?php
include 'header.php';
 ?>

   <!-- MAIN CONTENT AREA STARTS -->
   <div class="text-align-center contact-container">
     <h5 class="price-subheading">Come to our class, or take part in your own time</h5>
 <h1 class="price-heading">Yoga</h1>
   </div>
   <section class="margin-bottom">
   <div class="grid-x grid-margin-x container">
     <div class="cell small-12 medium-12 large-6">
       <div class="about-title-container">
       <div class="about-text">
         <h3>Can't make the class? Take part in your own time!</h3>
         <p>In this class, postures are practiced to align, strengthen and promote flexibility in the body. Breathing techniques and meditation are also integrated. You can expect an emphasis on simplicity, repetition, and ease of movement. Full-body relaxation and balance are the goals, as we make a full circuit of the body’s range of motion with standing postures, twists, backbends, forward folds, and hip openers.</p>
       </div>
          <a href="timetable.php" class="button about-button">View Timetable</a>
     </div>
     </div>
     <div class="cell small-12 medium-12 large-6">
       <iframe width="100%" height="450" src="https://www.youtube.com/embed/qy_oIKf1ByM" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
     </div>
   </div>
    </section>

   <!-- MAIN CONTENT AREA ENDS -->

 <?php
 include 'footer.php';
 ?>
