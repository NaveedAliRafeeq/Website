<?php
$page = 'find-a-gym';
include 'header.php';
 ?>

   <!-- MAIN CONTENT AREA STARTS -->

<html>
  <body>
    <div id="map"></div>


    <script>
		// Create Map
		var map;
		function initMap() {
        map = new google.maps.Map(document.getElementById('map'), {
          center: {lat: 54.196159, lng: -2.161942},
          zoom: 6,
		  mapTypeId: 'hybrid'
        });

		// Create Sheffield
		var sheffieldmk = new google.maps.Marker({
		icon: 'assets/img/Logo-marker.png',
		position: {lat: 53.376896, lng: -1.473504} ,
		map: map
		});

		// Create InfoWindow object
		var sheffieldinfo = new google.maps.InfoWindow({
                content:
                        '<span style="font-family: Trebuchet MS; font-size:10pt; color: maroon"><img src="assets/img/Logo-marker.png"/><br/><b></b>GloboGym<br/>Sheffield, UK'
            });

        // Assign InfoWindow
        google.maps.event.addListener(sheffieldmk, 'click', function () { sheffieldinfo.open(map, sheffieldmk) });

		// Create Birmingham
		var birminghammk = new google.maps.Marker({
		icon: 'assets/img/Logo-marker.png',
		position: {lat: 52.498627, lng: -1.886924} ,
		map: map
		});

		// Create InfoWindow object
		var birminghaminfo = new google.maps.InfoWindow({
                content:
                        '<span style="font-family: Trebuchet MS; font-size:10pt; color: maroon"><img src="assets/img/Logo-marker.png"/><br/><b></b>GloboGym<br/>Birmingham, UK'
            });

        // Assign InfoWindow
        google.maps.event.addListener(birminghammk, 'click', function () { birminghaminfo.open(map, birminghammk) });

		// Create Leeds
		var leedsmk = new google.maps.Marker({
		icon: 'assets/img/Logo-marker.png',
		position: {lat: 53.809098, lng: -1.548772} ,
		map: map
		});

		// Create InfoWindow object
		var leedsinfo = new google.maps.InfoWindow({
                content:
                        '<span style="font-family: Trebuchet MS; font-size:10pt; color: maroon"><img src="assets/img/Logo-marker.png"/><br/><b></b>GloboGym<br/>Leeds, UK'
            });

        // Assign InfoWindow
        google.maps.event.addListener(leedsmk, 'click', function () { leedsinfo.open(map, leedsmk) });

		// Create Manchester
		var manchestermk = new google.maps.Marker({
		icon: 'assets/img/Logo-marker.png',
		position: {lat: 53.486110, lng: -2.242330} ,
		map: map
		});

		// Create InfoWindow object
		var manchesterinfo = new google.maps.InfoWindow({
                content:
                        '<span style="font-family: Trebuchet MS; font-size:10pt; color: maroon"><img src="assets/img/Logo-marker.png"/><br/><b></b>GloboGym<br/>Manchester, UK'
            });

        // Assign InfoWindow
        google.maps.event.addListener(manchestermk, 'click', function () { manchesterinfo.open(map, manchestermk) });

		// Create Glasgow
		var glasgowmk = new google.maps.Marker({
		icon: 'assets/img/Logo-marker.png',
		position: {lat: 55.889545, lng: -4.247336} ,
		map: map
		});

		// Create InfoWindow object
		var glasgowinfo = new google.maps.InfoWindow({
                content:
                        '<span style="font-family: Trebuchet MS; font-size:10pt; color: maroon"><img src="assets/img/Logo-marker.png"/><br/><b></b>GloboGym<br/>Glasgow, UK'
            });

        // Assign InfoWindow
        google.maps.event.addListener(glasgowmk, 'click', function () { glasgowinfo.open(map, glasgowmk) });

		// Create Edinburgh
		var edinburghmk = new google.maps.Marker({
		icon: 'assets/img/Logo-marker.png',
		position: {lat: 55.964105, lng: -3.189452} ,
		map: map
		});

		// Create InfoWindow object
		var edinburghinfo = new google.maps.InfoWindow({
                content:
                        '<span style="font-family: Trebuchet MS; font-size:10pt; color: maroon"><img src="assets/img/Logo-marker.png"/><br/><b></b>GloboGym<br/>Edinburgh, UK'
            });

        // Assign InfoWindow
        google.maps.event.addListener(edinburghmk, 'click', function () { edinburghinfo.open(map, edinburghmk) });

		// Create Newcastle
		var newcastlemk = new google.maps.Marker({
		icon: 'assets/img/Logo-marker.png',
		position: {lat: 54.990344, lng: -1.617067} ,
		map: map
		});

		// Create InfoWindow object
		var newcastleinfo = new google.maps.InfoWindow({
                content:
                        '<span style="font-family: Trebuchet MS; font-size:10pt; color: maroon"><img src="assets/img/Logo-marker.png"/><br/><b></b>GloboGym<br/>Newcastle, UK'
            });

        // Assign InfoWindow
        google.maps.event.addListener(newcastlemk, 'click', function () { newcastleinfo.open(map, newcastlemk) });

		// Create York
		var yorkmk = new google.maps.Marker({
		icon: 'assets/img/Logo-marker.png',
		position: {lat: 53.958354, lng: -1.081622} ,
		map: map
		});

		// Create InfoWindow object
		var yorkinfo = new google.maps.InfoWindow({
                content:
                        '<span style="font-family: Trebuchet MS; font-size:10pt; color: maroon"><img src="assets/img/Logo-marker.png"/><br/><b></b>GloboGym<br/>York, UK'
            });

        // Assign InfoWindow
        google.maps.event.addListener(yorkmk, 'click', function () { yorkinfo.open(map, yorkmk) });

		// Create Liverpool
		var liverpoolmk = new google.maps.Marker({
		icon: 'assets/img/Logo-marker.png',
		position: {lat: 53.410831, lng: -2.962758} ,
		map: map
		});

		// Create InfoWindow object
		var liverpoolinfo = new google.maps.InfoWindow({
                content:
                        '<span style="font-family: Trebuchet MS; font-size:10pt; color: maroon"><img src="assets/img/Logo-marker.png"/><br/><b></b>GloboGym<br/>Liverpool, UK'
            });

        // Assign InfoWindow
        google.maps.event.addListener(liverpoolmk, 'click', function () { liverpoolinfo.open(map, liverpoolmk) });

		// Create Middlesbrough
		var middlesbroughmk = new google.maps.Marker({
		icon: 'assets/img/Logo-marker.png',
		position: {lat: 54.579389, lng: -1.236059} ,
		map: map
		});

		// Create InfoWindow object
		var middlesbroughinfo = new google.maps.InfoWindow({
                content:
                        '<span style="font-family: Trebuchet MS; font-size:10pt; color: maroon"><img src="assets/img/Logo-marker.png"/><br/><b></b>GloboGym<br/>Middlesbrough, UK'
            });

        // Assign InfoWindow
        google.maps.event.addListener(middlesbroughmk, 'click', function () { middlesbroughinfo.open(map, middlesbroughmk) });

		// Create Norwich
		var norwichmk = new google.maps.Marker({
		icon: 'assets/img/Logo-marker.png',
		position: {lat: 52.643299, lng: 1.297160} ,
		map: map
		});

		// Create InfoWindow object
		var norwichinfo = new google.maps.InfoWindow({
                content:
                        '<span style="font-family: Trebuchet MS; font-size:10pt; color: maroon"><img src="assets/img/Logo-marker.png"/><br/><b></b>GloboGym<br/>Norwich, UK'
            });

        // Assign InfoWindow
        google.maps.event.addListener(norwichmk, 'click', function () { norwichinfo.open(map, norwichmk) });

		// Create Peterborough
		var peterboroughmk = new google.maps.Marker({
		icon: 'assets/img/Logo-marker.png',
		position: {lat: 52.595812, lng: -0.245425} ,
		map: map
		});

		// Create InfoWindow object
		var peterboroughinfo = new google.maps.InfoWindow({
                content:
                        '<span style="font-family: Trebuchet MS; font-size:10pt; color: maroon"><img src="assets/img/Logo-marker.png"/><br/><b></b>GloboGym<br/>Peterborough, UK'
            });

        // Assign InfoWindow
        google.maps.event.addListener(peterboroughmk, 'click', function () { peterboroughinfo.open(map, peterboroughmk) });

		// Create London
		var londonmk = new google.maps.Marker({
		icon: 'assets/img/Logo-marker.png',
		position: {lat: 51.529730, lng: -0.122199} ,
		map: map
		});

		// Create InfoWindow object
		var londoninfo = new google.maps.InfoWindow({
                content:
                        '<span style="font-family: Trebuchet MS; font-size:10pt; color: maroon"><img src="assets/img/Logo-marker.png"/><br/><b></b>GloboGym<br/>London, UK'
            });

        // Assign InfoWindow
        google.maps.event.addListener(londonmk, 'click', function () { londoninfo.open(map, londonmk) });

		// Create Swindon
		var swindonmk = new google.maps.Marker({
		icon: 'assets/img/Logo-marker.png',
		position: {lat: 51.561671, lng: -1.780301} ,
		map: map
		});

		// Create InfoWindow object
		var swindoninfo = new google.maps.InfoWindow({
                content:
                        '<span style="font-family: Trebuchet MS; font-size:10pt; color: maroon"><img src="assets/img/Logo-marker.png"/><br/><b></b>GloboGym<br/>Swindon, UK'
            });

        // Assign InfoWindow
        google.maps.event.addListener(swindonmk, 'click', function () { swindoninfo.open(map, swindonmk) });

		// Create Southampton
		var southamptonmk = new google.maps.Marker({
		icon: 'assets/img/Logo-marker.png',
		position: {lat: 50.922321, lng: -1.408024} ,
		map: map
		});

		// Create InfoWindow object
		var southamptoninfo = new google.maps.InfoWindow({
                content:
                        '<span style="font-family: Trebuchet MS; font-size:10pt; color: maroon"><img src="assets/img/Logo-marker.png"/><br/><b></b>GloboGym<br/>Southampton, UK'
            });

        // Assign InfoWindow
        google.maps.event.addListener(southamptonmk, 'click', function () { southamptoninfo.open(map, southamptonmk) });

      }
    </script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAbM3cbFPtED8DrPJgDZ0t9jMliNSkwONU&callback=initMap"
    async defer></script>
  </body>
</html>

   <!-- MAIN CONTENT AREA ENDS -->

 <?php
 include 'footer.php';
 ?>
