<?php
include 'header.php';
 ?>

   <!-- MAIN CONTENT AREA STARTS -->
   <div class="text-align-center contact-container">
     <h5 class="price-subheading">Come to our class, or take part in your own time</h5>
 <h1 class="price-heading">GloboGym Cycle</h1>
   </div>
   <section class="margin-bottom">
   <div class="grid-x grid-margin-x container">
     <div class="cell small-12 medium-12 large-6">
       <div class="about-title-container">
       <div class="about-text">
         <h3>Can't make the class? Take part in your own time!</h3>
         <p>Our gyms come equipped with dedicated cycle studios filled with state of the art bikes. Within our spin classes, each participant is in complete control of their own resistance level and is a great fun workout - even if you can’t ride a bike! Our GloboGym Cycle classes are a fun workout and are a fantastic way of getting fit and burning calories to the latest chart-topping tunes.</p>
       </div>
          <a href="timetable.php" class="button about-button">View Timetable</a>
     </div>
     </div>
     <div class="cell small-12 medium-12 large-6">
       <iframe width="100%" height="450" src="https://www.youtube.com/embed/qo9cSpP3eGU" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
     </div>          
   </div>
    </section>

   <!-- MAIN CONTENT AREA ENDS -->

 <?php
 include 'footer.php';
 ?>
