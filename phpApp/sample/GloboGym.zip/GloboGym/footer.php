<!-- FOOTER AREA STARTS -->
<footer>
  <div class="footer">
    <div class="container grid-x">
      <div class="cell large-3 medium-3">
        <a href="index.html"><img src="assets/img/Logo.png" alt="logo"></a>
      </div>
      <div class="cell large-3 medium-3">
        <h1>GET IN TOUCH</h1>
        <ul>
          <li><a href="mailto:hello@globogym.co.uk?Subject=Hello%20again" target="_top">hello@globogym.co.uk</a></li>
          <li><a href="tel:555-555-5555">555-555-5555</a></li>
        </ul>
      </div>
      <div class="cell large-3 medium-3">
        <h1>OPENING TIMES</h1>
        <ul>
          <li>Monday - Friday</li>
          <li>06:00 - 22:00</li>
          <li>Weekends</li>
          <li>08:00 - 19:00 </li>
        </ul>
      </div>

      <div class="cell large-3 medium-3 icons">
        <h1>CONNECT</h1>
        <ul>
          <li><a href="https://www.facebook.com/" target="_blank"><i class="fa fa-facebook fa-2x"></i></a></li>
          <li> <a href="https://twitter.com/" target="_blank"><i class="fa fa-twitter fa-2x"></i></a></li>
          <li> <a href="https://www.instagram.com/" target="_blank"><i class="fa fa-instagram fa-2x"></i></a></li>
        </ul>
      </div>
      <div class="clearfix"></div>
    </div>
  </div>
</footer>
<!-- FOOTER AREA ENDS -->
<!-- BOTTOM FOOTER AREA STARTS -->
<div class="copyright">
  <div class="wrapper container grid-x">
    <div class="cell medium-12 large-12">
      <p>© 2009-2019 Globo Gym Limited</p>
    </div>
  </div>
</div>


<!-- BOTTOM FOOTER AREA ENDS -->
<script src="assets/js/vendor/jquery.js"></script>
<script src="assets/js/vendor/what-input.js"></script>
<script src="assets/js/vendor/foundation.js"></script>
<script src="assets/js/app.js"></script>
<script src="assets/js/vendor/globogym-scrips.js"></script>
</body>

</html>
