<?php
if (isset($_POST['newsletter-submit'])) {

  require 'connect_db.php';

  $emailN = $_POST['emailN'];

  if (empty($emailN)) {
    header("Location: ../../index.php?error=emptyfields");
    exit();
  }
  elseif (!filter_var($emailN, FILTER_VALIDATE_EMAIL)) {
    header("Location: ../../index.php?error=invalidmail");
    exit();
  }
  else {
$sql = "INSERT INTO newsletter_signups (emailN) VALUES (?)";
$stmt = mysqli_stmt_init($conn);
if (!mysqli_stmt_prepare($stmt, $sql)) {
  header("Location: ../../index.php?error=sqlerror");
  exit();
} else {
  mysqli_stmt_bind_param($stmt, "s", $emailN);
  mysqli_stmt_execute($stmt);
  header("Location: ../../index.php?signup=success");
  exit();
}
}
mysqli_stmt_close($stmt);
mysqli_close($conn);

}

else {
  header("Location: ../../assets/index.php");
  exit();
}
