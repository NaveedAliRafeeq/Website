<?php

$servername = "localhost";
$dBUsername = "b5006070";
$dBPassword = "globo1";
$dBName = "b5006070_db2";

$conn = mysqli_connect ($servername, $dBUsername, $dBPassword, $dBName);

if (!$conn) {
  die("Connection failed: ".mysqli_connect_error());
}
