<?php

if (isset($_POST['contact-submit'])) {

require 'connect_db';

  $name = $_POST['name'];
  $subject = $_POST['subject'];
  $mailFrom = $_POST['mail'];
  $message = $_POST['message'];

  $mailTo = "b5006070@my.shu.ac.uk";
  $headers = "From: ".$mailFrom;
  $txt = "You have recieved an E-Mail from ".$name.".\n\n".$message

mail($mailTo, $subject, $txt, $headers);
header("Location: ../../contact.php?mailsend");
}
