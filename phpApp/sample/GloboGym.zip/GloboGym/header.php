<?php
session_start();
 ?>

<!doctype html>
<html class="no-js" lang="en" dir="ltr">

<head>
  <meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>GloboGym</title>
  <link rel="stylesheet" href="assets/css/foundation.css">
  <link rel="stylesheet" href="assets/css/app.css">
  <link rel="stylesheet" href="assets/css/styles.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="assets/fonts/flaticon/font/flaticon.css">
</head>

<body>
  <!-- TOPBAR AREA STARTS -->
  <div class="top-nav" id="myTopnav">
    <div class="grid-x container">
      <div class="cell large-6 medium-6 small-12">
        <ul class="top-list">
          <li><i class="fa fa-map-marker fa-2x"></i><a href="find-a-gym.php">Find a Gym</a></li>
        </ul>
      </div>
      <div class="cell large-6 medium-6 small-12">
        <ul id="menu-topmenu" class="top-list-right">
          <?php
            if (isset($_SESSION['userId'])) {
              echo '<li><form action="assets/includes/logout.inc.php" method="post">
                <button type="submit" name="logout-submit" class="button">Logout</button>
              </form></li>';
            }
            else {
              echo '<li><a data-open="loginModal" class="button">Login</a></li>
                  <li><a href="signup.php" class="button">Signup</a></li>';
            }
           ?>
          <!-- LOGIN MODAL STARTS -->
          <div class="reveal" id="loginModal" data-reveal>
            <form action="assets/includes/login.inc.php" method="post" class="login-form">
              <div class="imgcontainer">
                <img src="assets/img/Logo.png" alt="Avatar" class="avatar">
              </div>
              <h4 class="text-center">Login with you username</h4>
              <label>Username
                <input type="text" name="user_id" placeholder="Enter Username" required>
              </label>
              <label>Password
                <input type="password" name="pass" placeholder="Enter Password" required>
              </label>
              <input id="show-password" type="checkbox"><label for="show-password">Show password</label>
              <p><button type="submit" name="login-submit">Login</button></p>
              <p class="text-center"><a href="signup.php">Dont have an account?</a></p>
            </form>
          </div>
          <!-- LOGIN MODAL ENDS -->
        </ul>
      </div>
    </div>
  </div>
  <!-- TOPBAR AREA ENDS -->
  <!-- NAVIGATION AREA STARTS -->
  <div data-sticky-container>
    <div class="top-bar container" id="myTopbar" data-sticky data-sticky-on="small" data-options="marginTop:0;" data-top-anchor="myTopnav:bottom" style="width:100%">
      <div class="title-bar-left">
        <div class="logo-area">
          <a href="index.php"><img src="assets/img/Logo.png" alt="logo"></a>
        </div>
      </div>
      <div class="title-bar-right">
        <ul class="menu align-right">
          <li><a href="index.php" class="<?php if($page=='home'){echo 'current';}?>">Home</a></li>
          <li><a href="find-a-gym.php" class="<?php if($page=='find-a-gym'){echo 'current';}?>">Find a Gym</a></li>
          <li><a href="classes.php" class="<?php if($page=='classes'){echo 'current';}?>">Classes</a></li>
          <li><a href="contact.php" class="<?php if($page=='contact'){echo 'current';}?>">Contact us</a></li>
        </ul>
      </div>
    </div>
  </div>






  <!-- NAVIGATION AREA ENDS -->
