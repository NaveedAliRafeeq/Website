<?php
$page = 'contact';
include 'header.php';
 ?>
<link rel="stylesheet" href="styles.css">
   <!-- MAIN CONTENT AREA STARTS -->


   <div class="text-align-center contact-container">
     <h5 class="price-subheading">Come visit out HQ</h5>
 <h1 class="price-heading">Contact GloboGym</h1>
   </div>

   <section class="map-area section-padding">
       <div class="container">
           <div class="row">
               <div class="col-lg-12">
                 <div id="map"></div>
  <script>
    var map;
    function initMap() {
      map = new google.maps.Map(document.getElementById('map'), {
        center: {lat: 53.369287, lng: -1.495944},
        zoom: 12,
    mapTypeId: 'hybrid'
      });

      // Create Sheffield
      var sheffieldmk = new google.maps.Marker({
      icon: 'assets/img/Logo-marker.png',
      position: {lat: 53.376896, lng: -1.473504} ,
      map: map
    	});
    }
  </script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAbM3cbFPtED8DrPJgDZ0t9jMliNSkwONU&callback=initMap"
  async defer></script>
               </div>
           </div>
       </div>
   </section>

<section class="contact-form">
  <div class="container margin-bottom150">
    <div class="grid-x">
      <div class="cell large-3">
        <div class="display-flex">
            <div class="into-icon">
                <i class="fa fa-home"></i>
            </div>
            <div class="info-text">
                <h5>Sheffield, United Kingdom</h5>
                <p>Ecclesall road</p>
            </div>
        </div>
        <div class="display-flex">
            <div class="into-icon">
                <i class="fa fa-phone"></i>
            </div>
            <div class="info-text">
                <h5>555-555-5555</h5>
                <p>Mon to Fri 7am to 6pm</p>
            </div>
        </div>
        <div class="display-flex">
            <div class="into-icon">
                <i class="fa fa-envelope-o"></i>
            </div>
            <div class="info-text">
                <h5><a href="mailto:hello@globogym.com?subject=Hello">hello@globogym.com</a></h5>
                <p>Send us your query anytime!</p>
            </div>
        </div>
      </div>
      <div class="cell large-9">
        <form class="contact-form" action="asssets/includes/contactform.inc.php" method="post">
          <div class="left">
          <input type="text" name="name" placeholder="Full name">
          <input type="text" name="mail" placeholder="Your E-Mail">
          <input type="text" name="subject" placeholder="Subject">
          </div>
          <div class="right">
             <textarea name="message" cols="20" rows="7"  placeholder="Enter Message" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Message'" required></textarea>
          </div>
          <button TYPE="submit" name="contact-submit" class="contact-submit">Send Mail</button>
        </form>
      </div>
    </div>
  </div>
</section>

   <!-- MAIN CONTENT AREA ENDS -->

 <?php
 include 'footer.php';
 ?>
