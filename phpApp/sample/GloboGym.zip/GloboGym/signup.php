<?php
include 'header.php';
 ?>

   <!-- MAIN CONTENT AREA STARTS -->

<!-- Display body section with sticky form. -->

<section>
  <div class="container signup-container">
    <div class="text-align-center">
  <h1 class="price-heading">Create an Account</h1>
    </div>
  <form action="assets/includes/signup.inc.php" method="post">
    <input type="text" name="uid" placeholder="Username">
    <input type="text" name="mail" placeholder="Email">
    <input type="password" name="pass" placeholder="Password">
    <input type="password" name="pass-repeat" placeholder="Confirm Password">
    <button type="submit" name="signup-submit">Signup</button>
  </form>
  </div>
</section>

   <!-- MAIN CONTENT AREA ENDS -->

 <?php
 include 'footer.php';
 ?>
