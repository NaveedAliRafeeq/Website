<?php
include 'header.php';
 ?>

   <!-- MAIN CONTENT AREA STARTS -->
   <div class="text-align-center contact-container">
     <h5 class="price-subheading">Come to our class, or take part in your own time</h5>
 <h1 class="price-heading">Boxercise</h1>
   </div>
   <section class="margin-bottom">
   <div class="grid-x grid-margin-x container">
     <div class="cell small-12 medium-12 large-6">
       <div class="about-title-container">
       <div class="about-text">
         <h3>Can't make the class? Take part in your own time!</h3>
         <p>Popular with both male and female participants, an intense training session using boxing training techniques to increase your overall fitness experience.</p>
       </div>
          <a href="timetable.php" class="button about-button">View Timetable</a>
     </div>
     </div>
     <div class="cell small-12 medium-12 large-6">
       <iframe width="100%" height="450" src="https://www.youtube.com/embed/pWLEkO0MlXs" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
     </div>     
   </div>
    </section>

   <!-- MAIN CONTENT AREA ENDS -->

 <?php
 include 'footer.php';
 ?>
