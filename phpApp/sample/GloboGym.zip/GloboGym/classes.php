<?php
$page = 'classes';
include 'header.php';
 ?>
 <head>
<link rel="stylesheet" href="assets/css/styles.css">
</head>
   <!-- MAIN CONTENT AREA STARTS -->
   <div class="text-align-center contact-container">
     <h5 class="price-subheading">Join in with our classes</h5>
 <h1 class="price-heading">Check out our classes</h1>
   </div>

   <section class="margin-bottom">
     <div class="container">
       <div class="grid-x">
         <div class="cell large-6 medium-12">
           <div class="card">
             <img src="assets/img/yoga.jpg" alt="yoga" class="card-img">
             <div class="card-section text-align-center"><a href="yoga.php">
               <h4>Yoga <span class="fa-stack"><i class="fa fa-circle-thin fa-stack-2x"></i><i class="fa fa-chevron-right fa-stack-1x"></i></span> </h4>
               <p>Our instructors will teach you the correct breathing techniques and guide you in how to get the most out of various yoga postures during this multi-level class.</p>
               </a>
             </div>
           </div>
         </div>
         <div class="cell large-6 medium-12">
           <div class="card">
             <img src="assets/img/bodytone.jpg" alt="bodytone">
             <div class="card-section text-align-center"><a href="bodytone.php">
               <h4>BodyTone <span class="fa-stack"><i class="fa fa-circle-thin fa-stack-2x"></i><i class="fa fa-chevron-right fa-stack-1x"></i></span> </h4>
               <p>A workout for anyone looking to get lean, toned and fit – fast. Using light to moderate weights with lots of repetition, giving you a total body workout.</p>
               </a>
             </div>
           </div>
         </div>
       </div>
       <div class="grid-x">
         <div class="cell large-6 medium-12">
           <div class="card">
             <img src="assets/img/boxersize.jpg" alt="boxercise">
             <div class="card-section text-align-center"><a href="boxercise.php">
               <h4>Boxercise <span class="fa-stack"><i class="fa fa-circle-thin fa-stack-2x"></i><i class="fa fa-chevron-right fa-stack-1x"></i></span> </h4>
               <p>Combining boxing moves alongside conditioning exercises. The class uses Aqua Bags, Bodyweight, Kettlebells, speed ropes & Ab rollers for a whole body workout.</p>
               </a>
             </div>
           </div>
         </div>
         <div class="cell large-6 medium-12">
           <div class="card">
             <img src="assets/img/cycle.jpg" alt="cycle">
             <div class="card-section text-align-center"> <a href="cycle.php">
               <h4>GloboGym Cycle <span class="fa-stack"><i class="fa fa-circle-thin fa-stack-2x"></i><i class="fa fa-chevron-right fa-stack-1x"></i></span> </h4>
               <p>Our dedicated cycle studio is equipped with state-of-the-art bikes and our classes are high energy, fun and keep you in complete control.</p>
               </a>
             </div>
           </div>
         </div>
       </div>
     </div>
   </section>
   <!-- NEWSLETTER AREA STARTS -->
   <section class="subscribe" style="background-image: url(assets/img/newsletter-bg.jpg);">
     <div class="container">
       <div class="section-header">
         <h2>25% <span>discount</span> </h2>
         <p>Subscribe to our newsletter and get<br>a discount code!</p>
       </div>

         <form action="assets/includes/newsletter.inc.php" method="post">
         <div class="form-row justify-content-center">
           <div class="col-auto">
             <input type="text" name="emailN" placeholder="Enter your Email">
           </div>
           <div class="col-auto">
             <button type="submit" name="newsletter-submit">Subscribe</button>
           </div>
         </div>
       </form>
     </div>
   </section>
   <!-- NEWSLETTER AREA ENDS -->
   <!-- MAIN CONTENT AREA ENDS -->

 <?php
 include 'footer.php';
 ?>
