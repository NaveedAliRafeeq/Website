
<?php
$page = 'home';
include 'header.php';
 ?>

  <!-- MAIN CONTENT AREA STARTS -->

  <!-- HERO AREA STARTS -->
  <section>
    <div class="hero-image">
      <div class="hero-text mySlides fade" style="background-image: url(assets/img/bg_1.jpg);">
        <div class="hero-text">
          <h1>Fuel your body fitness</h1>
          <a href="signup.php" class="button">Join Now</a>
        </div>
      </div>
      <div class="hero-text mySlides fade" style="background-image: url(assets/img/bg_2.jpg);">
        <div class="hero-text">
          <h1>Get fit with GloboGym</h1>
          <a href="timetable.php" class="button">Classes</a>
        </div>
      </div>
      <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
      <a class="next" onclick="plusSlides(1)">&#10095;</a>
    </div>
  </section>
  <!-- HERO AREA ENDS -->

  <!-- ABOUT AREA STARTS -->
  <section class="about">
    <div class="grid-x container">
      <div class="cell small-12 medium-6 large-6">
        <div class="about-title-container">
          <h5>welcome to globogym</h5>
          <h2>About <span>GloboGym</span></h2>
        </div>
        <div class="about-text">
          <h3>Making the decision to join a gym is a great first step towards improving your health and quality of life.</h3>
          <p>At GloboGym, we are here to help make your gym experience fun, effective and easy. For over 10 years, GloboGym has been dedicated to giving people a great fitness experience while helping people of all fitness levels reach their goals.
            Whether your goal is to stay in shape, lose weight or get fit for an upcoming event, we are here for you.</p>
        </div>
        <a href="signup.php" class="button about-button">Join Now</a>
      </div>
      <div class="cell small-12 medium-6 large-6">
        <div class="about-image"><img src="assets/img/about.jpg" alt=""></div>
      </div>
    </div>
  </section>

  <!-- ABOUT AREA ENDS -->

  <!-- BLOCK AREA STARTS -->
  <section>
    <div class="border-bottom">
      <div class="grid-x no-gutter">
        <div class="cell medium-6 large-3">
          <div class="width-100 height-100 block-feature padding-5 bg-light">
            <span class="display-block marginbottom-3">
              <span class="flaticon-padmasana display-4"></span>
            </span>
            <h2>Yoga</h2>
            <p>Our instructors will teach you the correct breathing techniques and guide you in how to get the most out of various yoga postures during this multi-level class.</p>
          </div>
        </div>
        <div class="cell medium-6 large-3">
          <div class="width-100 height-100 block-feature padding-5">
            <span class="display-block marginbottom-3">
              <span class="flaticon-weight display-4"></span>
            </span>
            <h2>BodyTone</h2>
            <p>A workout for anyone looking to get lean, toned and fit – fast. Using light to moderate weights with lots of repetition, giving you a total body workout.</p>
          </div>
        </div>
        <div class="cell medium-6 large-3">
          <div class="width-100 height-100 block-feature padding-5 bg-light">
            <span class="display-block marginbottom-3">
              <span class="flaticon-boxing-gloves display-4"></span>
            </span>
            <h2>Boxercise</h2>
            <p>Combining boxing moves alongside conditioning exercises. The class uses Aqua Bags, Bodyweight, Kettlebells, speed ropes & Ab rollers for a whole body workout.</p>
          </div>
        </div>
        <div class="cell medium-6 large-3">
          <div class="width-100 height-100 block-feature padding-5">
            <span class="display-block marginbottom-3">
              <span class="flaticon-spinning display-4"></span>
            </span>
            <h2>GloboGym Cycle</h2>
            <p>Our dedicated cycle studio is equipped with state-of-the-art bikes and our classes are high energy, fun and keep you in complete control.</p>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- BLOCK AREA ENDS -->

  <!-- PRICING AREA STARTS -->

  <section class="pricing">
    <div class="container">
      <div class="text-align-center">
        <h5 class="price-subheading">Pricing Tables</h5>
        <h2 class="price-heading">Membership Plans</h2>
      </div>

      <div class="grid-x grid-margin-x">
        <div class="cell medium-4 large-4">
          <div class="price-block text-align-center">
            <h3>Off-Peak</h3>
            <span class="price"><sup>£</sup><span class="number">7.99</span></span><br>
            <span class="except">a month + <span>joining fee</span></span><br>
            <a href="signup.php" class="button about-button">Get Started</a>

            <ul class="price-text">
              <li>&#10003; Access limited to off-peak hours</li>
              <li>&#10003; Book classes in off-peak hours 8 days in advance</li>
            </ul>
          </div>
        </div>

        <div class="cell medium-4 large-4">
          <div class="price-block text-align-center">
            <h3>Standard</h3>
            <span class="price"><sup>£</sup><span class="number">16.99</span></span><br>
            <span class="except">a month + <span>joining fee</span></span><br>
            <a href="signup.php" class="button about-button">Get Started</a><br>

            <ul class="price-text">
              <li>&#10003; Work-out when it suits you, day or night</li>
              <li>&#10003; Book classes like GloboGym Cycle to Boxercise 8 days in advance</li>
              <li>&#10003; Maximise your training by gaining access to 3 additional GloboGyms</li>
            </ul>
          </div>
        </div>

        <div class="cell medium-4 large-4">
          <div class="price-block text-align-center">
            <h3>Extra</h3>
            <span class="price"><sup>£</sup><span class="number">21.99</span></span><br>
            <span class="except">a month + <span>joining fee</span></span><br>
            <a href="signup.php" class="button about-button">Get Started</a>

            <ul class="price-text">
              <li>&#10003; Work-out when it suits you, day or night</li>
              <li>&#10003; Book classes 14 days in advance before anyone else</li>
              <li>&#10003; Maximise your training by gaining access to all GloboGyms</li>
              <li>&#10003; Freeze your membership at no additional cost for up to 6 months</li>
            </ul>
          </div>
        </div>

      </div>
    </div>
  </section>
  <!-- PRICING AREA ENDS -->

  <!-- NEWSLETTER AREA STARTS -->
  <section class="subscribe" style="background-image: url(assets/img/newsletter-bg.jpg);">
    <div class="container">
      <div class="section-header">
        <h2>25% <span>discount</span> </h2>
        <p>Subscribe to our newsletter and get<br>a discount code!</p>
      </div>

        <form action="assets/includes/newsletter.inc.php" method="post">
        <div class="form-row justify-content-center">
          <div class="col-auto">
            <input type="text" name="emailN" placeholder="Enter your Email">
          </div>
          <div class="col-auto">
            <button type="submit" name="newsletter-submit">Subscribe</button>
          </div>
        </div>
      </form>
    </div>
  </section>
  <!-- NEWSLETTER AREA ENDS -->

    <!-- MAIN CONTENT AREA ENDS -->

  <?php
  include 'footer.php';
  ?>
